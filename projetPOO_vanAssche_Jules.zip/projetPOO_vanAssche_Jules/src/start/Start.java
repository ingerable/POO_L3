package start;

import view.Gui;

public class Start {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		new Gui();

	}

}
